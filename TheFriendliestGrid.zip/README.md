FriendliestGrid
===============

A home made delicious grid that tasty and good for you too!

The Friendliest Grid was made with simplicity and ease of use in mind. Regardless of what level your html and css skills are, this grid system can help to you to craft better sites that work across all browsers and devices.

The documentation is located in the documentation.html file.

I am making my own personal grid system to speed up my development time and maybe yours too!

Some will like it and some will not. Thanks.
