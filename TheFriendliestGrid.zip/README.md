FriendliestGrid
===============

A home made delicious grid that tasty and good for you too!

I am making my own personal grid system to speed up my development time and maybe yours too!

Some will like it and some will not. Thanks.
